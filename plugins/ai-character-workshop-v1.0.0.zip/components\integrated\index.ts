/**
 * AI 角色工坊 - 集成面板标签页组件导出
 */

export { StyleTab } from './StyleTab';
export { BasicTab } from './BasicTab';
export { AppearanceTab } from './AppearanceTab';
export { PersonalityTab } from './PersonalityTab';
export { BackstoryTab } from './BackstoryTab';
export { AgentTab } from './AgentTab';
